<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link href="../css/ebaui_default.css" rel="stylesheet" type="text/css" />
    <script src="../ebaui.js" type="text/javascript" ></script>

</head>
<body>

<?php
    phpinfo();
?>

</body>
</html>